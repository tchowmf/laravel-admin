@extends('TemplateAdmin.index')
@section('contents')
<h1 class="h3 mb-4 text-gray-800">Excluir Marca de produtos</h1>
@endsection

<!-- 
    php artisan make:migration create_table_marca 
-->