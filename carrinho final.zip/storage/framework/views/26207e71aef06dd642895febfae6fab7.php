
<?php $__env->startSection('contents'); ?>
<h1 class="h3 mb-4 text-gray-800">Inclusão de uma nova Cor</h1>
<div class="card">
        <div class="card-header">
            Criar nova cor
        </div>
        <div class="card-body">
            <form method="post" action="/cor/novo">
                <?php echo csrf_field(); ?>
                <label class="form-label">Nome da cor</label>
                <input class="form-control" name="cor" placeholder="Digite o nome da cor"> 

                <label class="form-label">Situação</label>
                <select class="form-control" name='situacao'>           
                <option value="1" selected>Ativo</option>
                <option value="0">Inativo</option>            
                </select>  
                <br/>
                <input type="submit" class="btn btn-success" value="Salvar">
            </form>  
        </div>
</div>  
<?php $__env->stopSection(); ?>

<!-- 
    php artisan make:migration create_table_marca 
-->
<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\si\Desktop\Roner\Admin\Admin\resources\views/Cor/formulario.blade.php ENDPATH**/ ?>