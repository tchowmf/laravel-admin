
<?php $__env->startSection('contents'); ?>
    <h1 class="h3 mb-4 text-gray-800">Categoria de produtos</h1>
    
    <div class="card">
        <div class="card-header">
           Categorias
        </div>
        <div class="card-body">
            <a href='/categoria/novo' class="btn btn-success">
                Novo
            </a>
            <table class="table table-bordered dataTable">
                <thead>
                    <td>ID</td>
                    <td>Nome</td>                    
                    <td>Situação</td>
                </thead>            
                <tbody>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($linha['id']); ?></td>
                            <td><?php echo e($linha['nome']); ?> </td>
                            <td><?php echo e($linha['situacao']); ?></td>
                            <td>
                                <a href="#" class="btn btn-success"><li class="fa fa-edit"></li></a>
                                <a href="#" class="btn btn-danger"><li class="fa fa-trash"></li></a>
                            </td>                 
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<!-- 
    php artisan make:migration create_table_marca 
-->
<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\si\Desktop\Roner\Admin\Admin\resources\views/Categoria/index.blade.php ENDPATH**/ ?>