
<?php $__env->startSection('contents'); ?>
<h1 class="h3 mb-4 text-gray-800">Inclusão de uma nova Categoria</h1>
<div class="card">
        <div class="card-header">
            Criar nova categoria
        </div>
        <div class="card-body">
            <form method="post" action="/categoria/novo">
                <?php echo csrf_field(); ?>
                <label class="form-label">Nome da categoria</label>
                <input class="form-control" name="nome" placeholder="Digite o nome da categoria"> 

                <label class="form-label">Situação</label>
                <select class="form-control" name='situacao'>           
                <option value="1" selected>Ativo</option>
                <option value="0">Inativo</option>            
                </select>  
                <br/>
                <input type="submit" class="btn btn-success" value="Salvar">
            </form>  
        </div>
</div>  
<?php $__env->stopSection(); ?>

<!-- 
    php artisan make:migration create_table_marca 
-->
<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\si\Desktop\Roner\Admin\Admin\resources\views/Categoria/formulario.blade.php ENDPATH**/ ?>