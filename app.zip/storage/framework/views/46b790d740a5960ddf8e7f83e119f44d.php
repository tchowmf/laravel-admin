<?php $__env->startSection('contents'); ?>
    <h1 class="h3 mb-4 text-gray-800">Cadastro de Produtos</h1>

    <div class="card">
        <div class="card-header">
           Categorias
        </div>
        <div class="card-body">
            <a href='/produto/novo' class="btn btn-success">Novo Produto</a>
            <br><table class="table table-bordered dataTable"><br>
                <thead>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Quantidade</th>
                    <th>Categoria</th>
                    <th>Marca</th>
                    <th>Cor</th>
                    <th>Descrição</th>
                    <th>Opções</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dados['id']); ?></td>
                        <td><?php echo e($dados['nome']); ?></td>
                        <td><?php echo e($dados['preco']); ?></td>
                        <td><?php echo e($dados['quantidade']); ?></td>
                        <td><?php echo e($dados['cat']); ?></td>
                        <td><?php echo e($dados['marc']); ?></td>
                        <td><?php echo e($dados['cor']); ?></td>
                        <td><?php echo $dados['descricao']; ?></td>
                        <td>
                            <a href="/produto/update/<?php echo e($dados['id']); ?>" class="btn btn-success"><li class="fa fa-edit"></li></a>
                            <a href="/produto/excluir/<?php echo e($dados['id']); ?>" class="btn btn-danger"><li class="fa fa-trash"></li></a>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<!--
    php artisan make:migration create_table_marca
-->

<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vitor\Downloads\Admin\Admin\resources\views/Produto/index.blade.php ENDPATH**/ ?>