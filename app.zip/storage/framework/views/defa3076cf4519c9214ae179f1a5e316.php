<?php $__env->startSection('contents'); ?>

<?php

    $titulo = "Inclusão de um novo Produto";
    $endpoint = "/produto/novo";
    $input_id = "";
    $input_nome = "";
    $input_preco = "";
    $input_quantidade = "";
    $input_id_categoria = "";
    $input_id_marca = "";
    $input_id_cor = "";
    $input_descricao = "";

    if(isset($produto)) {
        $titulo = "Alteração do Produto";
        $endpoint = "/produto/update";
        $input_id = $produto["id"];
        $input_nome = $produto["nome"];
        $input_preco = $produto["preco"];
        $input_quantidade = $produto["quantidade"];
        $input_id_categoria = $produto["id_categoria"];
       $input_id_cor = $produto["id_cor"];
        $input_id_marca = $produto["id_marca"];
        $input_descricao = $produto["descricao"];
    }

?>


<h1 class="h3 mb-4 text-gray-800"><?php echo e($titulo); ?></h1>
<div class="card">
    <div class="card-header">
        Criar novo Produto
    </div>
        <div class="card-body">
            <form method="post" action="<?php echo e($endpoint); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($input_id); ?>"/>

                <label class="form-label">Nome do Produto</label>
                <input class="form-control" name="nome" placeholder="Digite o nome do PRODUTO" value="<?php echo e($input_nome); ?>">

                <label class="form-label">Preço</label>
                <input class="form-control" name="preco" placeholder="Digite o preço do PRODUTO" value="<?php echo e($input_preco); ?>">

                <label class="form-label">Quantidade</label>
                <input class="form-control" name="quantidade" placeholder="Digite a quantidade do PRODUTO" value="<?php echo e($input_quantidade); ?>">

                <label class="form-label">Categoria</label>
                <select name='id_categoria' class="form-control">
                    <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dado['id']); ?>" <?php echo e($dado['id'] == $input_id_categoria ? 'selected' : ''); ?>>
                            <?php echo e($dado['nome']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label class="form-label">Marca</label>
                <select name='id_marca' class="form-control">
                    <?php $__currentLoopData = $marca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dado['id']); ?>" <?php echo e($dado['id'] == $input_id_marca ? 'selected' : ''); ?>>
                            <?php echo e($dado['nome']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label class="form-label">Cores</label>
                <select name='id_cor' class="form-control">
                    <?php $__currentLoopData = $cor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dado['id']); ?>" <?php echo e($dado['id'] == $input_id_cor ? 'selected' : ''); ?>>
                            <?php echo e($dado['nome']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label class="form-label">Descrição</label>
                <textarea class="form-control" name="descricao" id="matheus" placeholder="Digite a descrição do PRODUTO"><?php echo e($input_descricao); ?></textarea>

                <br><input type="submit" class="btn btn-success" value="Salvar">
            </form>
        </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    ClassicEditor
        .create( document.querySelector( '#matheus' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>
<!--
    php artisan make:migration create_table_marca
-->

<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vitor\Downloads\Admin\Admin\resources\views/Produto/formulario.blade.php ENDPATH**/ ?>