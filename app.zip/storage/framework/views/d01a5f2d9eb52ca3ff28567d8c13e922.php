
<?php $__env->startSection('contents'); ?>
<h1 class="h3 mb-4 text-gray-800">Alterar Cor</h1>
<?php $__env->stopSection(); ?>

<!-- 
    php artisan make:migration create_table_marca 
-->
<?php echo $__env->make('TemplateAdmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\si\Desktop\Roner\Admin\Admin\resources\views/Cor/alterar.blade.php ENDPATH**/ ?>